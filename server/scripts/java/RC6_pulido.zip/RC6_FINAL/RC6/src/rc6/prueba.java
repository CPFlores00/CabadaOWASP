/*
 * Prueba.java
 * Creado el 08/05/2019
 * Seguridad informatica MJ 3-4:30pm
 */
package rc6;

import java.util.ArrayList;

/**
 * Clase de pruebas del Cifrado RC6
 *
 * @author Andrea Díaz Gutiérrez
 * @author José Carlos Grandío Robles
 * @author Jesús Iván González López
 * @author Carlos Raul Flores Carballo
 */
public class prueba {

    public static void main(String[] args) {

        Control c = new Control();
        c.cifrar("compa asi no se juega", "123456789abcdefg");
        System.out.println(c.getTcifra());
        c.descifrar("123456789abcdefg");
        System.out.println(c.getTdesci());

    }

}
